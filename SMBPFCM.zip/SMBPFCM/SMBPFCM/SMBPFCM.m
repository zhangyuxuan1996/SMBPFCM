% The core function of the SMBPFCM
%For more details, please refer to "Similarity Measure-Based Possibilistic FCM With
% Label Information for Brain MRI Segmentation" in IEEE Transactions on Cybernetics, 2018.
function result=SMBPFCM(coor,C,U,V)
[N,~]=size(coor);
%Parameters
a=0.65;            
b=1-a;
v=sum(coor)/N;
d=sqrt(sum((coor-v(ones(N,1),:)).^2,2));
d_avg=sum(d)/N;
h=abs(d-d_avg);
H=sum(h)/N;
delta=2;% This is a key parameter, delta=2 performs better for 01,03,04.bmp, while delta=6 performs better for 02.bmp
% For different nonlinearly point data, delta should be well tuned.
V=V+eps;
D = zeros(N,C);
for i=1:C
    D(:,i) = sum((coor-repmat(V(i,:),N,1)).^2,2);    
end
GAMA = sum(U.^2.*(D.'),2)./(sum(U.^2,2));
GAMA = b./GAMA;
T=rand(C,N);
RHO=zeros(C,N); 
t=0;
while(t<100) 
U=U.^2;       % m=2
T=T.^2;       % eta=2
P=a*U+b*T;
[max_colP,~]=max(P);
FP=(P==max_colP(ones(C,1),:));
P=P.*FP;
for k=1:N
     point=coor(k,:);
     DD=sqrt(sum((coor-point(ones(N,1),:)).^2,2));
end
    sigmas = max(max(DD));
for k=1:N
    point=coor(k,:);
    DD=sqrt(sum((coor-point(ones(N,1),:)).^2,2));
    F=(DD<delta*d_avg);
    W1=(DD./H).^2;      
    W1=F.*W1;  
    W1=exp(-W1);
    W2=DD./sigmas;
    W2=exp(-W2);
    W=W1.*W2;
    RHO(:,k)=(P*W)./(sum(P,2)+eps);
end
[max_colRHO,~]=max(RHO);
FRHO=(RHO==max_colRHO(ones(C,1),:));
X = zeros(C,C);
RHO_NEW = zeros(C,N);
for m=1:C
    for n = 1:C
         RHO_NEW(m,:) = (FRHO(m,:)|FRHO(n,:)).*RHO(m,:);
         RHO_NEW(n,:) = (FRHO(m,:)|FRHO(n,:)).*RHO(n,:);
         X(m,n) = sum(RHO_NEW(m,:).*RHO_NEW(n,:),2)./((sum(RHO_NEW(m,:),2)*sum(RHO_NEW(n,:),2)).^0.5+eps);
    end
end
RHO= X*RHO;
RHO=RHO.^2;
col_sum_RHO=sum(RHO);
U_new=RHO./col_sum_RHO(ones(C,1),:)+eps;
RHO=1./RHO;
T_new=1./(RHO.*(GAMA(:,ones(1,N)))+1)+eps;
epsilon=max(max(abs(U_new-U)));
if epsilon<1e-5
    break;
else
    U=U_new;
    T=T_new;
end
t=t+1;
end

result=a*U_new+b*T_new;