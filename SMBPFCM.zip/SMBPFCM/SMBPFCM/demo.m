% Written by Yuxuan Zhang
% If you use this code, please cite the paper "Xiangzhi Bai, Yuxuan Zhang, Haonan Liu, and Zhiguo Chen,
%" Similarity Measure-Based Possibilistic FCM With Label Information for Brain MRI Segmentation"
% IEEE Transactions on Cybernetics, 2018
%Date of Publication: 21 May 2018 
%DOI:10.1109/TCYB.2018.2830977
% If you have any questions, feel free to contact me(zhangyuxuan1996@buaa.edu.cn)
% Also, feel free to make modifications on it
clear ;
close all;
clc;
img=imread('..\Point Images\04.bmp');
%Read Image
if numel(size(img))>2
    IMG=rgb2gray(img); 
else 
    IMG=img;
end
[Height,Width]=size(IMG);
Size=Height*Width;
%read the position where the value of the pixel is zero and save the coordinates
IMG_srt=(IMG==0);
Coor_data = zeros(sum(sum(IMG_srt)),2);
k=1;
for i=1:Height
    for j=1:Width
        if (IMG_srt(i,j)==1)
            Coor_data(k,1)=i;
            Coor_data(k,2)=j;
            k=k+1;
        end
    end
end
imin = 1;
imax = 256;
C=3;% Cluster numbers
%Initialization
[U,center]=FCM_Point(Coor_data,imin,imax,C,1e-5);
tic
% The proposed method
SMBPFCM_result=SMBPFCM(Coor_data,C,U,center);
plot(Coor_data(:,2), Height-Coor_data(:,1),'o','MarkerSize',3);title('SMBPFCM','fontname','Times New Roman','FontSize',30)
maxU = max(SMBPFCM_result);
index1 = find(SMBPFCM_result(1,:) == maxU&maxU~=0);
index2 = find(SMBPFCM_result(2,:) == maxU&maxU~=0);
index3 = find(SMBPFCM_result(3,:) == maxU&maxU~=0);
hold on
plot(Coor_data(index1, 2),Height-Coor_data(index1,1),'g+','MarkerSize',3)
hold on 
plot(Coor_data(index2, 2),Height-Coor_data(index2,1),'r+','MarkerSize',3)
hold on
plot(Coor_data(index3, 2),Height-Coor_data(index3,1),'m+','MarkerSize',3)
toc
