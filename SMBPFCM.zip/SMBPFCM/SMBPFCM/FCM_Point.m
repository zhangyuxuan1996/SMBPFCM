%Written by Yuxuan Zhang
% This function is to initialize the membership matrix and cluster centers using FCM
function [U,V]=FCM_Point(IMG,imin,imax,C,epsilon)
t=0; 
[Height,~]=size(IMG);
U=rand(Height,C);
U_sum = sum(U,2);
U = U./U_sum(:,ones(1,C));
V=randi([imin,imax],C,2);
distan = zeros(Height,C);
while(t<100)
     for i=1:C
         distan(:,i) = (IMG(:,1)-V(i,1)).^2+(IMG(:,2)-V(i,2)).^2+eps;
     end    
     U = 1./distan./repmat(sum(1./distan,2),1,C);
     V_new = zeros(C,2);
     for i=1:C
     V_new(i,:) = sum((repmat(U(:,i),1,2)).^2.*IMG)./sum((repmat(U(:,i),1,2)).^2);
     end
     tmpmatrix=max((V(:,1)-V_new(:,1)).^2+(V_new(:,2)-V(:,2)).^2);
     if tmpmatrix<epsilon
        break;
     else
      V= V_new;
     end
    t=t+1;
end
U = U.';
end